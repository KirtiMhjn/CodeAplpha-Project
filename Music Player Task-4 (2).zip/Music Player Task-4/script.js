const audio = document.getElementById('audio');
const playButton = document.getElementById('play');
const pauseButton = document.getElementById('pause');
const nextButton = document.getElementById('next');
const prevButton = document.getElementById('prev');
const title = document.getElementById('title');

const tracks = [
    {
        title: "Song 1",
        src: "da821fcf052648b3ad28f9533602c00e.mp4"
    },
    {
        title: "Song 2",
        src: "my fav.mp4"
    },
    {
        title: "Song 3",
        src: "record20220901181832.amr"
    }
];

let currentTrack = 0;

function loadTrack(trackIndex) {
    const track = tracks[trackIndex];
    title.textContent = track.title;
    audio.src = track.src;
}

playButton.addEventListener('click', () => {
    audio.play();
});

pauseButton.addEventListener('click', () => {
    audio.pause();
});

nextButton.addEventListener('click', () => {
    currentTrack = (currentTrack + 1) % tracks.length;
    loadTrack(currentTrack);
    audio.play();
});

prevButton.addEventListener('click', () => {
    currentTrack = (currentTrack - 1 + tracks.length) % tracks.length;
    loadTrack(currentTrack);
    audio.play();
});

// Load the first track by default
loadTrack(currentTrack);
